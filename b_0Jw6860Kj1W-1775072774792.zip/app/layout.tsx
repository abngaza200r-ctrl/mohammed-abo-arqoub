import type { Metadata } from 'next'
import { Tajawal } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const tajawal = Tajawal({ 
  subsets: ["arabic", "latin"],
  weight: ["200", "300", "400", "500", "700", "800", "900"]
});

export const metadata: Metadata = {
  title: 'Mohammed Abo Arqoub | مطور ويب ومسوق رقمي',
  description: 'محمد أبو عرقوب - مطور مواقع، مسوق رقمي، ومتخصص في السوشيال ميديا من فلسطين. أساعدك في بناء وتطوير تواجدك الرقمي.',
  generator: 'v0.app',
  keywords: ['مطور ويب', 'تصميم مواقع', 'سوشيال ميديا', 'فلسطين', 'غزة', 'تطوير تطبيقات'],
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ar" dir="rtl">
      <body className={`${tajawal.className} antialiased`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
