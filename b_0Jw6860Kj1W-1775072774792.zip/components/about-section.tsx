"use client"

import { MapPin, Code, Megaphone, MessageSquare, Github, Send, Facebook, Instagram } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

const infoCards = [
  {
    icon: MapPin,
    title: "من فلسطين",
    subtitle: "غزة العزة",
    color: "from-red-500/20 to-green-500/20",
  },
  {
    icon: Code,
    title: "مطور ويب",
    subtitle: "Front & Back End",
    color: "from-blue-500/20 to-cyan-500/20",
  },
  {
    icon: Megaphone,
    title: "مسوق رقمي",
    subtitle: "Social Media",
    color: "from-purple-500/20 to-pink-500/20",
  },
  {
    icon: MessageSquare,
    title: "مستشار تقني",
    subtitle: "للمشاريع الناشئة",
    color: "from-orange-500/20 to-yellow-500/20",
  },
]

const skills = [
  { name: "تطوير المواقع (HTML/CSS/JS/PHP)", percentage: 85, color: "from-blue-500 to-cyan-500" },
  { name: "إدارة السوشيال ميديا", percentage: 90, color: "from-purple-500 to-pink-500" },
  { name: "بوتات تيليجرام (Python/PHP)", percentage: 80, color: "from-green-500 to-emerald-500" },
  { name: "قواعد البيانات", percentage: 75, color: "from-orange-500 to-yellow-500" },
]

const socialLinks = [
  { icon: Instagram, href: "https://instagram.com/uvvlj", label: "Instagram" },
  { icon: Facebook, href: "https://facebook.com/Mohammed.Abo.Arqob", label: "Facebook" },
  { icon: Send, href: "https://t.me/uvvlj", label: "Telegram" },
  { icon: Github, href: "https://github.com/moammdx", label: "GitHub" },
]

export function AboutSection() {
  return (
    <section id="about" className="py-24 px-4 relative">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)", backgroundSize: "40px 40px" }} />
      </div>

      <div className="container mx-auto relative z-10">
        {/* Social Links */}
        <div className="flex justify-center gap-4 mb-12">
          {socialLinks.map((link, index) => (
            <a
              key={index}
              href={link.href}
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 rounded-full bg-secondary/80 flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/10 hover:scale-110 transition-all duration-300"
              aria-label={link.label}
            >
              <link.icon size={22} />
            </a>
          ))}
        </div>

        {/* Section Title */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-black text-foreground mb-4">من أنا؟</h2>
          <div className="w-24 h-1.5 bg-gradient-to-l from-primary to-cyan-500 mx-auto rounded-full" />
        </div>

        {/* Info Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-20">
          {infoCards.map((card, index) => (
            <Card
              key={index}
              className="bg-card/80 backdrop-blur-sm border-border hover:border-primary/50 transition-all duration-500 hover:-translate-y-2 hover:shadow-xl hover:shadow-primary/10 group overflow-hidden"
            >
              <CardContent className="p-6 relative">
                {/* Background gradient on hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${card.color} opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
                
                <div className="relative flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-colors">
                    <card.icon className="text-primary" size={28} />
                  </div>
                  <div className="text-right">
                    <h3 className="font-bold text-lg text-foreground">{card.title}</h3>
                    <p className="text-sm text-muted-foreground">{card.subtitle}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* About Text */}
        <div className="max-w-4xl mx-auto text-center mb-20">
          <div className="bg-card/50 backdrop-blur-sm border border-border rounded-3xl p-8 md:p-12">
            <p className="text-lg md:text-xl text-muted-foreground leading-loose">
              أنا <span className="text-primary font-bold text-2xl">محمد أبو عرقوب</span>، شاب طموح من فلسطين - غزة.
              شغوف بكل ما يتعلق بمجال التقنية، تطوير المواقع، وإدارة السوشيال ميديا.
              أعمل على صناعة المحتوى الرقمي وتقديم حلول برمجية تساعد الأفراد والشركات على النمو.
            </p>
          </div>
        </div>

        {/* Skills */}
        <div className="max-w-3xl mx-auto">
          <h3 className="text-2xl font-bold text-center mb-10 text-foreground">المهارات التقنية</h3>
          <div className="space-y-8">
            {skills.map((skill, index) => (
              <div key={index} className="group">
                <div className="flex justify-between items-center mb-3">
                  <span className="text-foreground font-semibold text-lg">{skill.name}</span>
                  <span className="text-primary font-bold text-xl">{skill.percentage}%</span>
                </div>
                <div className="h-4 bg-secondary rounded-full overflow-hidden shadow-inner">
                  <div
                    className={`h-full bg-gradient-to-l ${skill.color} rounded-full transition-all duration-1000 ease-out relative`}
                    style={{ width: `${skill.percentage}%` }}
                  >
                    <div className="absolute inset-0 bg-white/20 animate-pulse" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
