"use client"

import Image from "next/image"
import { ExternalLink, Award, Eye } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

const projects = [
  {
    title: "TEAM CR - منصة تعلم البرمجة",
    description: "منصة تعلم البرمجة والأمن السيبراني مع أفضل الدورات التفاعلية والتمارين العملية.",
    image: "/images/team-cr.jpg",
    tags: ["React", "Next.js", "Tailwind"],
    category: "مواقع برمجية",
    gradient: "from-green-500 to-emerald-500",
  },
  {
    title: "خدمات السوشيال ميديا",
    description: "عروض زيادة نمو حسابك بأفضل الخصومات - متابعين، إعجابات، مشاهدات لجميع المنصات.",
    image: "/images/social-services.jpg",
    tags: ["Marketing", "Design", "Content"],
    category: "منتجات رقمية",
    gradient: "from-pink-500 to-purple-500",
  },
  {
    title: "شهادة الأمن السيبراني",
    description: "شهادة إتمام Cybersecurity Boot-Camp من Black Academy.",
    image: "/images/certificate.jpg",
    tags: ["Cybersecurity", "Certificate"],
    category: "شهادات",
    isCertificate: true,
    gradient: "from-yellow-500 to-orange-500",
  },
]

const technologies = [
  { name: "React", color: "from-cyan-500 to-blue-500" },
  { name: "JavaScript", color: "from-yellow-400 to-yellow-600" },
  { name: "CSS", color: "from-blue-400 to-blue-600" },
  { name: "HTML", color: "from-orange-400 to-red-500" },
  { name: "PHP", color: "from-indigo-400 to-purple-600" },
  { name: "Python", color: "from-green-400 to-emerald-600" },
  { name: "Next.js", color: "from-gray-400 to-gray-600" },
  { name: "Tailwind", color: "from-cyan-400 to-teal-500" },
]

export function PortfolioSection() {
  return (
    <section id="portfolio" className="py-24 px-4 relative">
      {/* Background Effect */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/3 left-0 w-72 h-72 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/3 right-0 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto relative z-10">
        {/* Section Title */}
        <div className="text-center mb-20">
          <span className="text-primary font-medium text-lg mb-4 block">معرض الأعمال</span>
          <h2 className="text-4xl md:text-5xl font-black text-foreground mb-6">أعمالي وإنجازاتي</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            بعض المشاريع والأعمال التي عملت عليها
          </p>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {projects.map((project, index) => (
            <Card
              key={index}
              className="bg-card/80 backdrop-blur-sm border-border overflow-hidden hover:border-primary/30 transition-all duration-500 hover:-translate-y-3 hover:shadow-2xl hover:shadow-primary/10 group"
            >
              <div className="relative h-56 overflow-hidden">
                <Image
                  src={project.image}
                  alt={project.title}
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-700"
                />
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-card via-card/50 to-transparent opacity-60" />
                
                {/* Category Badge */}
                <div className="absolute top-4 right-4">
                  <span className={`px-4 py-1.5 bg-gradient-to-r ${project.gradient} text-white text-sm font-medium rounded-full shadow-lg`}>
                    {project.category}
                  </span>
                </div>
                
                {/* Certificate Badge */}
                {project.isCertificate && (
                  <div className="absolute top-4 left-4">
                    <div className="w-10 h-10 rounded-full bg-yellow-500/20 backdrop-blur-sm flex items-center justify-center">
                      <Award className="text-yellow-400" size={22} />
                    </div>
                  </div>
                )}

                {/* View Overlay */}
                <div className="absolute inset-0 flex items-center justify-center bg-background/80 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="w-14 h-14 rounded-full bg-primary/20 flex items-center justify-center">
                    <Eye className="text-primary" size={24} />
                  </div>
                </div>
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-foreground mb-3 group-hover:text-primary transition-colors">{project.title}</h3>
                <p className="text-muted-foreground mb-5 text-sm leading-relaxed">{project.description}</p>
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag, tagIndex) => (
                    <span
                      key={tagIndex}
                      className="px-3 py-1.5 bg-secondary/80 text-xs text-muted-foreground rounded-lg border border-border"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Technologies */}
        <div className="text-center">
          <h3 className="text-2xl font-bold text-foreground mb-8">التقنيات التي أستخدمها</h3>
          <div className="flex flex-wrap justify-center gap-4">
            {technologies.map((tech, index) => (
              <div
                key={index}
                className="group relative px-6 py-3 bg-card/80 backdrop-blur-sm rounded-xl border border-border hover:border-primary/30 transition-all duration-300 cursor-default overflow-hidden"
              >
                <div className={`absolute inset-0 bg-gradient-to-r ${tech.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`} />
                <span className="relative text-foreground font-medium group-hover:text-primary transition-colors">{tech.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
