"use client"

import { Share2, Globe, Smartphone, Megaphone, Database, Code, ArrowLeft } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

const services = [
  {
    icon: Share2,
    title: "إدارة حسابات السوشيال ميديا",
    description: "إدارة شاملة لحساباتك وزيادة التفاعل والوصول للجمهور المستهدف.",
    tags: ["Instagram", "Facebook", "TikTok"],
    gradient: "from-pink-500 to-purple-500",
  },
  {
    icon: Globe,
    title: "إنشاء وتصميم مواقع",
    description: "تصميم مواقع تعريفية (Landing Page / Portfolio) عصرية ومتجاوبة.",
    tags: ["HTML", "CSS", "React", "Next.js"],
    gradient: "from-blue-500 to-cyan-500",
  },
  {
    icon: Smartphone,
    title: "تطوير بوتات تيليجرام",
    description: "برمجة وتعديل بوتات تيليجرام لخدمة أهدافك التجارية أو الشخصية.",
    tags: ["Telegram API", "PHP", "Python"],
    gradient: "from-green-500 to-emerald-500",
  },
  {
    icon: Megaphone,
    title: "إعداد حملات إعلانية",
    description: "إطلاق وإدارة حملات إعلانية ممولة تحقق نتائج ملموسة.",
    tags: ["Meta Ads", "Google Ads"],
    gradient: "from-orange-500 to-red-500",
  },
  {
    icon: Database,
    title: "استشارات تقنية",
    description: "تقديم المشورة التقنية للمشاريع الصغيرة والمتوسطة.",
    tags: ["Planning", "Strategy"],
    gradient: "from-violet-500 to-purple-500",
  },
  {
    icon: Code,
    title: "حلول برمجية",
    description: "المساعدة في حل المشاكل البرمجية (PHP / Python / DB).",
    tags: ["Debugging", "Database", "API"],
    gradient: "from-cyan-500 to-blue-500",
  },
]

export function ServicesSection() {
  return (
    <section id="services" className="py-24 px-4 bg-gradient-to-b from-background via-secondary/20 to-background relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
      <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary/50 to-transparent" />

      <div className="container mx-auto relative z-10">
        {/* Section Title */}
        <div className="text-center mb-20">
          <span className="text-primary font-medium text-lg mb-4 block">ماذا أقدم لك؟</span>
          <h2 className="text-4xl md:text-5xl font-black text-foreground mb-6">الخدمات التي أقدمها</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            مجموعة متكاملة من الخدمات الرقمية لتطوير أعمالك وتعزيز تواجدك الرقمي
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card
              key={index}
              className="bg-card/80 backdrop-blur-sm border-border hover:border-primary/30 transition-all duration-500 hover:-translate-y-3 hover:shadow-2xl hover:shadow-primary/10 group overflow-hidden"
            >
              <CardContent className="p-8 relative">
                {/* Gradient line on top */}
                <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${service.gradient} transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-right`} />
                
                {/* Icon */}
                <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${service.gradient} flex items-center justify-center mb-6 shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                  <service.icon className="text-white" size={30} />
                </div>

                {/* Title */}
                <h3 className="text-xl font-bold text-foreground mb-4 group-hover:text-primary transition-colors">{service.title}</h3>
                
                {/* Description */}
                <p className="text-muted-foreground mb-6 leading-relaxed">{service.description}</p>
                
                {/* Tags */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {service.tags.map((tag, tagIndex) => (
                    <span
                      key={tagIndex}
                      className="px-3 py-1 bg-secondary/80 text-sm text-muted-foreground rounded-lg border border-border group-hover:border-primary/30 transition-colors"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Learn More Link */}
                <a
                  href="#contact"
                  className="inline-flex items-center text-primary font-medium group/link"
                >
                  <span>اطلب الخدمة</span>
                  <ArrowLeft size={18} className="mr-2 group-hover/link:-translate-x-1 transition-transform" />
                </a>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
