"use client"

import { Mail, Send, Phone, MapPin, ArrowLeft } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const socialLinks = [
  {
    name: "Instagram",
    username: "@uvvlj",
    icon: (
      <svg viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
      </svg>
    ),
    url: "https://instagram.com/uvvlj",
    gradient: "from-pink-500 via-purple-500 to-orange-500",
  },
  {
    name: "Facebook",
    username: "Mohammed Abo Arqob",
    icon: (
      <svg viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
      </svg>
    ),
    url: "https://facebook.com/Mohammed.Abo.Arqob",
    gradient: "from-blue-600 to-blue-500",
  },
  {
    name: "Telegram",
    username: "@uvvlj",
    icon: (
      <svg viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
        <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
      </svg>
    ),
    url: "https://t.me/uvvlj",
    gradient: "from-cyan-500 to-blue-500",
  },
  {
    name: "GitHub",
    username: "moammdx",
    icon: (
      <svg viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
        <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
      </svg>
    ),
    url: "https://github.com/moammdx",
    gradient: "from-gray-600 to-gray-800",
  },
]

const contactInfo = [
  {
    icon: Mail,
    title: "البريد الإلكتروني",
    value: "moammdsalcr@gmail.com",
    href: "mailto:moammdsalcr@gmail.com",
  },
  {
    icon: Phone,
    title: "الهاتف",
    value: "0599950104",
    href: "tel:+970599950104",
  },
  {
    icon: MapPin,
    title: "الموقع",
    value: "فلسطين - غزة",
    href: null,
  },
]

export function ContactSection() {
  return (
    <section id="contact" className="py-24 px-4 bg-gradient-to-b from-secondary/30 to-background relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-cyan-500/5 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto max-w-5xl relative z-10">
        {/* Section Title */}
        <div className="text-center mb-16">
          <span className="text-primary font-medium text-lg mb-4 block">تواصل معي</span>
          <h2 className="text-4xl md:text-5xl font-black text-foreground mb-6">هل لديك مشروع؟</h2>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto">
            جاهز لبدء مشروع جديد؟ لا تتردد في مراسلتي وسأرد عليك في أقرب وقت.
          </p>
        </div>

        <Card className="bg-card/80 backdrop-blur-sm border-border shadow-2xl shadow-primary/5">
          <CardContent className="p-8 md:p-12">
            {/* Contact Info */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              {contactInfo.map((info, index) => (
                <div
                  key={index}
                  className="bg-secondary/50 rounded-2xl p-6 text-center hover:bg-secondary/80 transition-colors group"
                >
                  <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
                    <info.icon className="text-primary" size={26} />
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{info.title}</p>
                  {info.href ? (
                    <a
                      href={info.href}
                      className="text-foreground font-semibold hover:text-primary transition-colors"
                    >
                      {info.value}
                    </a>
                  ) : (
                    <span className="text-foreground font-semibold">{info.value}</span>
                  )}
                </div>
              ))}
            </div>

            {/* Social Links */}
            <div className="mb-12">
              <h3 className="text-xl font-bold text-center text-foreground mb-8">تابعني على</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {socialLinks.map((social, index) => (
                  <a
                    key={index}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group bg-secondary/50 rounded-2xl p-6 text-center hover:bg-secondary transition-all duration-300 hover:-translate-y-1"
                  >
                    <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${social.gradient} flex items-center justify-center mx-auto mb-4 text-white shadow-lg group-hover:scale-110 transition-transform`}>
                      {social.icon}
                    </div>
                    <p className="text-foreground font-semibold text-sm">{social.name}</p>
                    <p className="text-muted-foreground text-xs mt-1">{social.username}</p>
                  </a>
                ))}
              </div>
            </div>

            {/* CTA Card */}
            <div className="bg-gradient-to-br from-primary/10 to-cyan-500/10 border border-primary/20 rounded-3xl p-8 md:p-10 text-center">
              <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4">دعنا نعمل معاً</h3>
              <p className="text-muted-foreground mb-8 max-w-lg mx-auto text-lg">
                سواء كنت تحتاج لموقع جديد، إدارة حساباتك، أو استشارة تقنية، أنا هنا للمساعدة.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  asChild
                  size="lg"
                  className="bg-gradient-to-l from-primary to-cyan-500 hover:opacity-90 text-primary-foreground px-10 py-6 text-lg rounded-xl shadow-lg shadow-primary/30"
                >
                  <a href="mailto:moammdsalcr@gmail.com">
                    <Mail className="ml-2" size={20} />
                    أرسل لي رسالة
                  </a>
                </Button>
                <Button
                  asChild
                  variant="outline"
                  size="lg"
                  className="border-2 border-border hover:border-primary/50 px-10 py-6 text-lg rounded-xl"
                >
                  <a href="https://wa.me/970599950104" target="_blank" rel="noopener noreferrer">
                    <Send className="ml-2" size={20} />
                    واتساب
                  </a>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
