"use client"

import Image from "next/image"
import { Code, Share2, Send, ExternalLink, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center pt-20 pb-12 px-4 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-radial from-primary/5 to-transparent rounded-full" />
      </div>

      <div className="container mx-auto relative z-10">
        <div className="flex flex-col items-center text-center">
          {/* Profile Image with Badges */}
          <div className="relative mb-10 group">
            {/* Outer Ring Animation */}
            <div className="absolute inset-[-8px] rounded-full border-2 border-primary/20 animate-spin-slow" />
            <div className="absolute inset-[-16px] rounded-full border border-primary/10" />
            
            {/* Glow Effect */}
            <div className="absolute inset-0 bg-gradient-to-br from-primary/30 to-cyan-500/20 rounded-full blur-2xl scale-110 group-hover:scale-125 transition-transform duration-500" />
            
            {/* Profile Image */}
            <div className="relative w-56 h-56 md:w-72 md:h-72 lg:w-80 lg:h-80 rounded-full overflow-hidden border-4 border-primary/40 shadow-2xl shadow-primary/20">
              <Image
                src="/images/profile.jpg"
                alt="Mohammed Abo Arqoub"
                fill
                className="object-cover object-center scale-110"
                priority
              />
              {/* Overlay gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-background/20 to-transparent" />
            </div>

            {/* Developer Badge */}
            <div className="absolute -top-4 right-0 md:-top-6 md:-right-12 bg-card/90 backdrop-blur-sm px-4 py-2.5 rounded-2xl flex items-center gap-2 shadow-xl border border-primary/30 animate-float">
              <span className="text-sm font-semibold text-foreground">Developer</span>
              <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
                <Code size={16} className="text-primary" />
              </div>
            </div>

            {/* Social Media Badge */}
            <div className="absolute top-1/2 -left-4 md:-left-20 -translate-y-1/2 bg-card/90 backdrop-blur-sm px-4 py-2.5 rounded-2xl flex items-center gap-2 shadow-xl border border-primary/30 animate-float" style={{ animationDelay: "1.5s" }}>
              <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
                <Share2 size={16} className="text-primary" />
              </div>
              <span className="text-sm font-semibold text-foreground">Social Media</span>
            </div>

            {/* Experience Badge */}
            <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 bg-primary px-5 py-2.5 rounded-xl shadow-xl animate-float" style={{ animationDelay: "0.5s" }}>
              <span className="text-sm font-bold text-primary-foreground">+5 سنوات خبرة</span>
            </div>
          </div>

          {/* Welcome Badge */}
          <div className="bg-gradient-to-r from-secondary/80 to-secondary/40 backdrop-blur-sm border border-border/50 px-8 py-3 rounded-full mb-8 animate-fade-in-up">
            <span className="text-muted-foreground text-lg">مرحباً بك في موقعي الشخصي</span>
          </div>

          {/* Name */}
          <h1 className="text-4xl md:text-5xl lg:text-7xl font-black mb-4 animate-fade-in-up" style={{ animationDelay: "0.1s" }}>
            <span className="text-foreground">أنا </span>
            <span className="bg-gradient-to-l from-primary via-cyan-400 to-primary bg-clip-text text-transparent">محمد أبو عرقوب</span>
          </h1>

          <p className="text-xl md:text-2xl text-muted-foreground mb-3 animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
            Mohammed Abo Arqoub
          </p>

          {/* Title */}
          <div className="flex flex-wrap justify-center gap-3 mb-8 animate-fade-in-up" style={{ animationDelay: "0.3s" }}>
            <span className="px-4 py-1.5 bg-primary/10 border border-primary/30 rounded-full text-primary font-medium">Digital Creator</span>
            <span className="px-4 py-1.5 bg-primary/10 border border-primary/30 rounded-full text-primary font-medium">Developer</span>
            <span className="px-4 py-1.5 bg-primary/10 border border-primary/30 rounded-full text-primary font-medium">Social Media Specialist</span>
          </div>

          {/* Description */}
          <p className="text-muted-foreground max-w-2xl mb-10 text-lg md:text-xl leading-relaxed animate-fade-in-up" style={{ animationDelay: "0.4s" }}>
            أساعدك في بناء وتطوير تواجدك الرقمي من خلال حلول تقنية وإبداعية متكاملة.
            من تطوير المواقع إلى إدارة السوشيال ميديا.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 animate-fade-in-up" style={{ animationDelay: "0.5s" }}>
            <Button
              asChild
              size="lg"
              className="bg-gradient-to-l from-primary to-cyan-500 hover:opacity-90 text-primary-foreground px-10 py-6 text-lg rounded-xl shadow-lg shadow-primary/30 transition-all hover:shadow-xl hover:shadow-primary/40 hover:-translate-y-1"
            >
              <a href="#contact">
                <Send className="ml-2" size={20} />
                تواصل معي
              </a>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="border-2 border-border hover:border-primary/50 hover:bg-secondary/50 px-10 py-6 text-lg rounded-xl transition-all hover:-translate-y-1"
            >
              <a href="#portfolio">
                <ExternalLink className="ml-2" size={20} />
                شاهد أعمالي
              </a>
            </Button>
          </div>

          {/* Scroll Indicator */}
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
            <a href="#about" className="flex flex-col items-center text-muted-foreground hover:text-primary transition-colors">
              <span className="text-sm mb-2">اكتشف المزيد</span>
              <ChevronDown size={24} />
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
