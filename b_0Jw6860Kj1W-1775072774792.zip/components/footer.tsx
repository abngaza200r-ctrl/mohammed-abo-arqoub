export function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="py-8 px-4 border-t border-border/50 bg-card/50">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Logo */}
          <a href="#home" className="group flex items-center gap-1">
            <span className="text-2xl font-black bg-gradient-to-l from-primary to-cyan-400 bg-clip-text text-transparent">MA</span>
            <span className="text-2xl font-black text-primary">.</span>
          </a>

          {/* Copyright */}
          <p className="text-muted-foreground text-center">
            <span className="text-foreground font-semibold">Mohammed Abo Arqoub</span>
            {" "}&copy; {currentYear}. جميع الحقوق محفوظة.
          </p>

          {/* Tags */}
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span className="hover:text-primary transition-colors cursor-default">Development</span>
            <span className="w-1 h-1 bg-muted-foreground rounded-full" />
            <span className="hover:text-primary transition-colors cursor-default">Design</span>
            <span className="w-1 h-1 bg-muted-foreground rounded-full" />
            <span className="hover:text-primary transition-colors cursor-default">Content</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
